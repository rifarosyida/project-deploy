<?php

session_start();

require_once "../controllers/login_controller.php";

if ( isset($_POST['login']) ) {
  
    $nip = $_POST['nip'];
    $password = $_POST['password'];

    $result = login($nip, $password, 'pegawai');

    if(!empty($result)) {
        $_SESSION["pegawaiLogedin"] = true;
        $_SESSION["name"] = $result["account_name"];
        $_SESSION["nip"] = $result["nip"];
        header('Location: dashboardPegawai.php');
    } else {
        echo "<script>alert('Username atau password salah');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login Pegawai | Sigaset</title>

    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <!-- css -->
    <link rel="stylesheet" type="text/css" href= "../css/loginStyle.css" />

</head>
<body>
    <form action="" method="post" class="col-sm-4 m-auto shadow-sm p-3 bg-light mt-5 rounded-3">
        <h2 class="fw-bold text-center fg-title mt-4">SIGASET</h2>
        <p class="text-center">Login Pegawai</p>
        <div class="mb-3">
            <label for="nip" class="form-label">NIP</label>
            <input type="text" name="nip" id="nip" class="form-control" placeholder="Masukkan NIP" required>
        </div>
        <div class="mb-5">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" required>
        </div>
        <div class="d-flex mb-5">
            <input type="submit" value="Masuk" class="btn btn-bg-login rounded-3 w-100" name="login">
        </div>
    </form>
</body>
</html>