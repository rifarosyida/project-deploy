<?php 

session_start();

require_once '../controllers/functions.php';

if (!isset($_SESSION["adminLogedin"])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST["submit"])) {
    if (insert($_POST) > 0) {

        // insert nip into data utama
        insert_nip("data_utama", $_POST['nip']);

        echo "<script>
                alert('Data berhasil ditambahkan');
                window.location.href = 'dashboardAdmin.php';
            </script>";
    } else {
        echo "<script>alert('Data gagal ditambahkan')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigaset | Tambah User</title>

     <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">   

</head>
<body style="background-color: #e1ac6a;">
    <div class="container">
        <form action="#" method="POST" class="col-sm-6 p-5 rounded-3 shadow-sm m-auto mt-5 mb-5 bg-light">
            <div class="mb-3">
                <h2 class="fw-bold">Tambah Data User</h2>
                <hr>
            </div>    
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" name="nama" id="nama" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="nip" class="form-label">NIP</label>
                <input type="text" name="nip" id="nip" class="form-control" oninput="fillPassword()" required>
            </div>            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="text" name="password" id="password" class="form-control" readonly>
                <div id="passHelp" class="form-text">Default password adalah NIP user</div>
            </div>
            <div class="mb-4">
                <label for="role" class="form-label">Role</label>
                <select class="form-select" aria-label="role select" id="role" name="role">
                    <option value="admin">Admin</option>
                    <option value="pegawai">Pegawai</option>
                </select>
            </div>
            <div class="d-flex justify-content-end">
                <input type="reset" name="reset" value="Batal" class="btn btn-secondary mx-2" onclick="window.location.href = 'dashboardAdmin.php'">
                <input type="submit" name="submit" value="Simpan" class="btn btn-primary">
            </div>
        </form>
    </div>

    <!-- script -->
    <script>
        function fillPassword() {
            var element = document.getElementById('nip');

            var pass = document.getElementById('password');

            pass.value = element.value;
        }
    </script>
</body>
</html>