<?php 

session_start();

require_once '../controllers/functions.php';

if (!isset($_SESSION["pegawaiLogedin"])) {
    header("Location: loginPegawai.php");
    exit;
}

$id = $_GET["id"];

$data = get("SELECT * FROM riwayat_pendidikan WHERE id = '$id'");

if (isset($_POST["submit"])) {
    $nama_pendidikan = htmlspecialchars($_POST["nama"]);
    $no_ijazah = htmlspecialchars($_POST["no_ijazah"]);
    $tgl_ijazah = htmlspecialchars($_POST["tgl_ijazah"]);
    $institusi = htmlspecialchars($_POST["institusi"]);
    $kota = htmlspecialchars($_POST["kota"]);
    $nip = $_SESSION["nip"];

    $queryBuilder = "UPDATE riwayat_pendidikan SET nama_pendidikan = '$nama_pendidikan',
        no_ijazah = '$no_ijazah',
        tanggal_ijazah = '$tgl_ijazah',
        nama_institusi = '$institusi',
        kota = '$kota'
        WHERE id = '$id'";
    if (updates($queryBuilder) > 0) {

        echo "<script>
                alert('Data berhasil ditambahkan');
                window.location.href = 'dashboardPegawaiPendidikan.php';
            </script>";
    } else {
        echo "<script>alert('Data gagal ditambahkan')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigaset | Edit Data Pangkat</title>

     <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">   

</head>
<body style="background-color: #e1ac6a;">
    <div class="container">
        <form action="#" method="POST" class="col-sm-6 p-5 rounded-3 shadow-sm m-auto mt-5 mb-5 bg-light">
            <div class="mb-3">
                <h2 class="fw-bold">Tambah Data Riwayat Pendidikan</h2>
                <hr>
            </div>    
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Pendidikan</label>
                <input type="text" name="nama" id="nama" value="<?= $data["nama_pendidikan"]?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="no_ijazah" class="form-label">No. Ijazah</label>
                <input type="text" name="no_ijazah" id="no_ijazah" value="<?= $data["no_ijazah"]?>" class="form-control" required>
            </div>            
            <div class="mb-3">
                <label for="tgl_ijazah" class="form-label">Tgl Ijazah</label>
                <input type="date" name="tgl_ijazah" id="tgl_ijazah" value="<?= $data["tanggal_ijazah"]?>" class="form-control" required>
            </div>
            <div class="mb-4">
                <label for="institusi" class="form-label">Nama Institusi</label>
                <input type="text" name="institusi" id="institusi" value="<?= $data["nama_institusi"]?>" class="form-control" required>
            </div>
            <div class="mb-4">
                <label for="kota" class="form-label">Kota</label>
                <input type="text" name="kota" id="kota" value="<?= $data["kota"]?>" class="form-control" required>
            </div>
            <div class="d-flex justify-content-end">
                <input type="reset" name="reset" value="Batal" class="btn btn-secondary mx-2" onclick="window.location.href = 'dashboardPegawai.php'">
                <input type="submit" name="submit" value="Update" class="btn btn-primary">
            </div>
        </form>
    </div>
</body>
</html>