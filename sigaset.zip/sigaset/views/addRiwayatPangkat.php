<?php 

session_start();

require_once '../controllers/functions.php';

if (!isset($_SESSION["pegawaiLogedin"])) {
    header("Location: loginPegawai.php");
    exit;
}

if (isset($_POST["submit"])) {
    $no_sk = htmlspecialchars($_POST["no_sk"]);
    $tgl_sk = htmlspecialchars($_POST["tgl_sk"]);
    $golongan = htmlspecialchars($_POST["golongan"]);
    $tmt_pangkat = htmlspecialchars($_POST["tmt"]);
    $nip = $_SESSION["nip"];

    $queryBuilder = "INSERT INTO riwayat_kepangkatan VALUES ('', '$nip', '$no_sk', '$tgl_sk', '$golongan', '$tmt_pangkat')";
    if (create($queryBuilder) > 0) {

        echo "<script>
                alert('Data berhasil ditambahkan');
                window.location.href = 'dashboardPegawaiPangkat.php';
            </script>";
    } else {
        echo "<script>alert('Data gagal ditambahkan')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigaset | Tambah Data Pangkat</title>

     <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">   

</head>
<body style="background-color: #e1ac6a;">
    <div class="container">
        <form action="#" method="POST" class="col-sm-6 p-5 rounded-3 shadow-sm m-auto mt-5 mb-5 bg-light">
            <div class="mb-3">
                <h2 class="fw-bold">Tambah Data Riwayat Pangkat</h2>
                <hr>
            </div>    
            <div class="mb-3">
                <label for="no_sk" class="form-label">No. Sk</label>
                <input type="text" name="no_sk" id="no_sk" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="tgl_sk" class="form-label">Tanggal SK</label>
                <input type="date" name="tgl_sk" id="tgl_sk" class="form-control" required>
            </div>            
            <div class="mb-3">
                <label for="golongan" class="form-label">Golongan/ Ruang</label>
                <input type="text" name="golongan" id="golongan" class="form-control" required>
            </div>
            <div class="mb-4">
                <label for="tmt" class="form-label">TMT Pangkat</label>
                <input type="text" name="tmt" id="tmt" class="form-control" required>
            </div>
            <div class="d-flex justify-content-end">
                <input type="reset" name="reset" value="Batal" class="btn btn-secondary mx-2" onclick="window.location.href = 'dashboardPegawai.php'">
                <input type="submit" name="submit" value="Simpan" class="btn btn-primary">
            </div>
        </form>
    </div>
</body>
</html>