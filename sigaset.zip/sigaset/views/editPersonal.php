<?php 

session_start();

require_once '../controllers/functions.php';

if (!isset($_SESSION["pegawaiLogedin"])) {
    header("Location: loginPegawai.php");
    exit;
}

if(isset($_POST["submit"])) {
    if(personal_update($_POST, $_SESSION["nip"], $_SESSION["name"]) > 0) {
        echo "
            <script>
                alert('update berhasil');
                window.location.href = 'dashboardPegawai.php';
            </script>
        ";
    }
}

$nip = $_SESSION["nip"];

$data = get("SELECT * FROM data_utama where nip = '$nip'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigaset | Edit Data Pribadi</title>

     <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">   

</head>
<body style="background-color: #e1ac6a;">
    <div class="container">
        <form action="#" method="POST" class="col-sm-10 p-5 rounded-3 shadow-sm m-auto mt-5 mb-5 bg-light">
            <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <h2 class="fw-bold">Data Pribadi</h2>
                    <hr>
                </div>    
                <div class="mb-3">
                    <label for="nip" class="form-label">NIP</label>
                    <input type="text" name="nip" id="nip" class="form-control" value="<?= $_SESSION["nip"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" name="nama" id="nama" class="form-control" value="<?= $_SESSION["name"] ?>" required>
                </div>            
                <div class="mb-3">
                    <label for="gelar_depan" class="form-label">Gelar Depan</label>
                    <input type="text" name="gelar_depan" id="gelar_depan" class="form-control"  value="<?= $data["gelar_depan"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="gelar_belakang" class="form-label">Gelar Belakang</label>
                    <input type="text" name="gelar_belakang" id="gelar_belakang" class="form-control" value="<?= $data["gelar_belakang"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="tempat_lahir" class="form-label">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" value="<?= $data["tempat_lahir"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
                    <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control" value="<?= $data["tanggal_lahir"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                    <select class="form-select" aria-label="Default select example" name="jenis_kelamin">
                        <option value="Laki-laki"
                        <?= ($data["jenis_kelamin"] == "Laki-laki") ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="Perempuan" <?= ($data["jenis_kelamin"] == "Perempuan") ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="agama" class="form-label">Agama</label>
                    <input type="text" name="agama" id="agama" class="form-control" value="<?= $data["agama"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="status_perkawinan" class="form-label">Status Perkawinan</label>
                    <input type="text" name="status_perkawinan" id="status_perkawinan" class="form-control" value="<?= $data["status_perkawinan"] ?>" required>
                </div>     
                <div class="mb-3">
                    <label for="desa" class="form-label">Desan/ Kelurahan</label>
                    <input type="text" name="desa" id="desa" class="form-control" value="<?= $data["desa_kelurahan"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="kecamatan" class="form-label">Kecamatan</label>
                    <input type="text" name="kecamatan" id="kecamatan" class="form-control" value="<?= $data["kecamatan"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="kabupaten" class="form-label">Kabupaten</label>
                    <input type="text" name="kabupaten" id="kabupaten" class="form-control" value="<?= $data["kabupaten_kota"] ?>" required>
                </div>     
                <div class="mb-3">
                    <label for="provinsi" class="form-label">Provinsi</label>
                    <input type="text" name="provinsi" id="provinsi" class="form-control" value="<?= $data["provinsi"] ?>" required>
                </div>     
                <div class="mb-3">
                    <label for="goldar" class="form-label">Golongan Darah</label>
                    <input type="text" name="goldar" id="goldar" class="form-control" value="<?= $data["golongan_darah"] ?>" required>
                </div>    
                <div class="d-flex justify-content-start">
                    <input type="reset" name="reset" value="Batal" class="btn btn-secondary mx-2" onclick="window.location.href = 'dashboardPegawai.php'">
                    <input type="submit" name="submit" value="Simpan" class="btn btn-primary">
                </div>                
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <h2 class="fw-bold">Data Kepegawaian</h2>
                    <hr>
                </div>    
                <div class="mb-3">
                    <label for="status_kepegawaian" class="form-label">Status Kepegawaian</label>
                    <input type="text" name="status_kepegawaian" id="status_kepegawaian" class="form-control" value="<?= $data["status_kepegawaian"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="kedudukan_hukum" class="form-label">Kedudukan Hukum</label>
                    <input type="text" name="kedudukan_hukum" id="kedudukan_hukum" class="form-control" value="<?= $data["kedudukan_hukum"] ?>" required>
                </div>            
                <div class="mb-3">
                    <label for="jenis_pegawai" class="form-label">Jenis Pegawai</label>
                    <input type="text" name="jenis_pegawai" id="jenis_pegawai" class="form-control" value="<?= $data["jenis_pegawai"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="no_kapreg" class="form-label">No. Kapreg</label>
                    <input type="text" name="no_kapreg" id="no_kapreg" class="form-control" value="<?= $data["no_kapreg"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="no_taspen" class="form-label">No. Taspen</label>
                    <input type="text" name="no_taspen" id="no_taspen" class="form-control" value="<?= $data["no_taspen"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="no_akses" class="form-label">No. Akses/ BPJS</label>
                    <input type="text" name="no_akses" id="no_akses" class="form-control" value="<?= $data["no_akses_bpjs"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="no_karis" class="form-label">No. Karis/ Karsu</label>
                    <input type="text" name="no_karis" id="no_karis" class="form-control" value="<?= $data["no_karis_karsu"] ?>" required>
                </div>
                <div class="mb-3">
                    <label for="status_kpe" class="form-label">Status KPE</label>
                    <input type="text" name="status_kpe" id="status_kpe" class="form-control" value="<?= $data["status_kpe"] ?>" required>
                </div>
            </div>
            </div>
            
        </form>
    </div>
</body>
</html>