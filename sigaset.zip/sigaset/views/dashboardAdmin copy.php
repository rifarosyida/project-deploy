<?php

session_start();

require_once '../controllers/functions.php';

if (!isset($_SESSION["adminLogedin"])) {
    header("Location: login.php");
}

$userDatas = [];
$userDatas = get_all("SELECT * FROM user");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sigaset | Dashboard Admin</title>

    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">   

    <!-- css -->
    <link rel="stylesheet" href="../css/dasboardStyle.css">

    <!-- fontawsome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
<!-- navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-brown shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">SIGASET</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle mx-5" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Halo, <?= $_SESSION["name"]; ?>
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="../controllers/logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- end of navbar -->

<!-- main table -->
<div class="container">
  <h2 class="fw-bold mt-5 text-center">Kelola Data User</h2>
  <div class="d-flex justify-content-end mt-4">
    <a href="addUser.php" class="btn btn-success">Tambah <i class="fa-solid fa-plus"></i></a>
  </div>
  <table class="table table-striped ">
    <thead>
      <tr>
        <th scope="col">id</th>
        <th scope="col">NIP</th>
        <th scope="col">Nama</th>
        <th scope="col">Role</th>
        <th scope="col" width="250px">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
        if(!$userDatas <= 0) {
          foreach ($userDatas as $user):
      ?>
          <tr>
            <td><?= $user["id"];?></td>
            <td><?= $user["nip"];?></td>
            <td><?= $user["account_name"];?></td>
            <td><?= $user["role"]; ?></td>
            <td>
              <a href="editUser.php?id=<?= $user["id"]; ?>" class="btn btn-primary rounded-3"><i class="fa-solid fa-pen-to-square"></i></a>
              <a href="../controllers/deleteUser.php?nip=<?= $user["nip"]; ?>" class="btn btn-danger rounded-3" onclick="return confirm('Hapus data?')"><i class="fa-solid fa-trash"></i></a>
              <a href="" class="btn btn-warning rounded-3" style="color: white !important; "><i class="fa-solid fa-eye"></i></a>
            </td>
          </tr>
          <?php endforeach; 
        }
      ?>
    </tbody>
  </table>
</div>
<!-- end of table -->

<!-- js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>