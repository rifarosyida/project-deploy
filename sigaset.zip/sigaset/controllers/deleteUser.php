<?php 

session_start();

require_once 'functions.php';

if (!isset($_SESSION["adminLogedin"])) {
    header("Location: login.php");
    exit;
}

$id = $_GET["id"];

if(after_delete($id) > 0) { // deleting the foreign data first
    delete($id);
    echo "<script>
            alert('Data berhasil dihapus');
            window.location.href = '../views/dashboardAdmin.php';
        </script>";
} else {
    echo "<script>alert('delete gagal')</script>";
}

?>