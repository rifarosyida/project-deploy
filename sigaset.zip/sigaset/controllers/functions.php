<?php 

include 'connection.php';

// get all data on the table 
function get_all($query) {
    global $conn;

    $result = [];
    $datas = mysqli_query($conn, $query);

    while ($r = mysqli_fetch_array($datas)) {
        $result[] = $r;
    }
    
    if(mysqli_num_rows($datas) > 0) {
        return $result;
    } else {
        return 0;
    }
}

// get data on the table
function get($query) {
    global $conn;

    $result = mysqli_query($conn, $query);
    $data = [];

    if(mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        return $data;
    } else {
        return 0;
    }
}

// deleting data by id
function delete($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM user WHERE nip = '$id'");

    return mysqli_affected_rows($conn);
}

// deleteing data by id and table

function deletes($table, $id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM $table WHERE id = '$id'");

    return mysqli_affected_rows($conn);
}

// deleteing foreign data
function after_delete($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM data_utama WHERE nip = '$id'");

    return mysqli_affected_rows($conn);
}

//inserting data
function insert($userData) {
    global $conn;
    
    $account_name = htmlspecialchars($userData["nama"]);
    $nip = htmlspecialchars($userData["nip"]);
    $password = htmlspecialchars($userData["password"]);
    $role = htmlspecialchars($userData["role"]);

    mysqli_query($conn, "INSERT INTO user VALUES ('', '$account_name', '$nip', '$password', '$role')");

    return mysqli_affected_rows($conn);
}

// inserting nip into foreign key each table
function insert_nip($tableName, $nip) {
    global $conn;

    mysqli_query($conn, "INSERT INTO $tableName (nip) VALUES ('$nip')");

    return mysqli_affected_rows($conn);
}

// insert using query
function create($query) {
    global $conn;

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

// updating data user
function update($userData, $id) {
    global $conn;

    $account_name = htmlspecialchars($userData["nama"]);
    $nip = htmlspecialchars($userData["nip"]);
    $password = htmlspecialchars($userData["password"]);
    $role = htmlspecialchars($userData["role"]);

    mysqli_query($conn, "UPDATE user SET account_name = '$account_name', nip = '$nip', password = '$password', role = '$role' WHERE id = '$id'");

    return mysqli_affected_rows($conn);
}
            
// update for personal data
function personal_update($data, $nip, $nama) {
    global $conn;

    $gelar_depan = htmlspecialchars($data["gelar_depan"]);
    $gelar_belakang = htmlspecialchars($data["gelar_belakang"]);
    $tempat_lahir = htmlspecialchars($data["tempat_lahir"]);
    $tanggal_lahir = htmlspecialchars($data["tgl_lahir"]);
    $jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
    $agama = htmlspecialchars($data["agama"]);
    $status_perkawinan = htmlspecialchars($data["status_perkawinan"]);
    $desa = htmlspecialchars($data["desa"]);
    $kecamatan = htmlspecialchars($data["kecamatan"]);
    $kabupaten = htmlspecialchars($data["kabupaten"]);
    $provinsi = htmlspecialchars($data["provinsi"]);
    $goldar = htmlspecialchars($data["goldar"]);
    $status_kepegawaian = htmlspecialchars($data["status_kepegawaian"]);
    $kedudukan_hukum = htmlspecialchars($data["kedudukan_hukum"]);
    $jenis_pegawai = htmlspecialchars($data["jenis_pegawai"]);
    $no_kapreg = htmlspecialchars($data["no_kapreg"]);
    $no_taspen = htmlspecialchars($data["no_taspen"]);
    $no_akses = htmlspecialchars($data["no_akses"]);
    $no_karis = htmlspecialchars($data["no_karis"]);
    $status_kpe = htmlspecialchars($data["status_kpe"]);

    $queryBuilder = "
        UPDATE data_utama SET nama = '$nama', 
            gelar_depan = '$gelar_depan',
            gelar_belakang = '$gelar_belakang',
            tempat_lahir = '$tempat_lahir',
            tanggal_lahir = '$tanggal_lahir',
            jenis_kelamin = '$jenis_kelamin',
            agama = '$agama',
            status_kepegawaian = '$status_kepegawaian',
            kedudukan_hukum = '$kedudukan_hukum',
            jenis_pegawai = '$jenis_pegawai',
            status_perkawinan = '$status_perkawinan',
            desa_kelurahan = '$desa',
            kecamatan = '$kecamatan',
            kabupaten_kota = '$kabupaten',
            provinsi = '$provinsi',
            golongan_darah = '$goldar',
            no_kapreg = '$no_kapreg',
            no_taspen = '$no_taspen',
            no_akses_bpjs = '$no_akses',
            no_karis_karsu = '$no_karis',
            status_kpe = '$status_kpe'
        WHERE nip = '$nip'

    ";

    mysqli_query($conn, $queryBuilder);

    return mysqli_affected_rows($conn);
}

function updates($query) {
    global $conn;

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}


?>