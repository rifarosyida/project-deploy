<?php 

session_start();

$redirectTo = "";

if(!(isset($_SESSION["adminLogedin"]) || isset($_SESSION["pegawaiLogedini"]))) {
    header("Location: ../index.php");
    exit;
} else {
    if(isset($_SESSION["adminLogedin"])) {
        $redirectTo = "Location: ../views/login.php";
    } else {
        $redirectTo = "Location: ../views/loginPegawai.php";
    }
}

session_unset();
session_destroy();

header($redirectTo);

?>