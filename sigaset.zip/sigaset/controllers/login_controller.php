<?php

include 'connection.php';

function login($nip, $password, $role) {
    global $conn;

    $result = mysqli_query($conn, "SELECT * FROM user WHERE nip = '$nip' and password = '$password' and role = '$role'");

    $userFound = mysqli_num_rows($result);

    if($userFound === 1) {       
        return mysqli_fetch_assoc($result);
    }
}