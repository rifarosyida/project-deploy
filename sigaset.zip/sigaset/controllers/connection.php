<?php


$hostname = "localhost";
$username = "root";
$password = "";
$dbName = "sigaset";

$conn = mysqli_connect($hostname, $username, $password, $dbName);