<?php 

session_start();

require_once 'functions.php';

if (!isset($_SESSION["pegawaiLogedin"])) {
    header("Location: loginPegawai.php");
    exit;
}

$id = $_GET["id"];

if(deletes("riwayat_kepangkatan", $id) > 0) { 
    echo "<script>
            alert('Data berhasil dihapus');
            window.location.href = '../views/dashboardPegawai.php';
        </script>";
} else {
    echo "<script>alert('delete gagal')</script>";
}

?>